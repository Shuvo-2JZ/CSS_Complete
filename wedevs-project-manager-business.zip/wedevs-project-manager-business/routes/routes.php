<?php

// use WeDevs\PM_Pro\Core\Router\Router;
// use WeDevs\PM_Pro\Core\Permissions\Administrator;

// $router = Router::singleton();

// $router->get( 'sample', 'WeDevs/PM_Pro/Core/Notifications/Emails/Daily_Digest@daily_digest' );